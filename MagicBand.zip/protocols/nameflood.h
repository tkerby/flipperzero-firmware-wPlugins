#pragma once
#include "_base.h"

// Hacked together by @Willy-JL

typedef struct {
    char name[20];
} NamefloodCfg;

extern const Protocol protocol_nameflood;
