ADD_SCENE(fastpair_model, FastpairModel)
ADD_SCENE(fastpair_model_custom, FastpairModelCustom)
