ADD_SCENE(swiftpair_name, SwiftpairName)
