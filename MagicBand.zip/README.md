# OFW_BLE_Spam
 BLE Magic app patched to work on OFW
